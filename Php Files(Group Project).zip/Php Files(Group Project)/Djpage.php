<!-- CSCI 466 Group project 
Created by:
Ahmed Elfaki 
Matthew Gidron Noutai
Michael Ibikunle -->

<html>
    <head>
        <title>CSCI 466 Project - DJ InterFace</title>
        <link href="https://students.cs.niu.edu/~z1877540/CSS_FILES/style.css" rel="stylesheet">   
        
    </head>
    
    <header>
                <div id="Homepage" class="page">
            <nav>  
                <ul class="navbar-nav">
                <li class="nav-item">
                    <button class="nav-link btn-link" onclick="location.href='https://students.cs.niu.edu/~z1877540/Homepage.html'">Home Page</button>
                </li>
                </ul>  
            </nav>
            </div>
    </header>
    
</html>
<!DOCTYPE html>
<html>
<head>
	<title>Order Info</title>
	<link href="https://students.cs.niu.edu/~z1877540/CSS_FILES/tablestyle.css" rel="stylesheet">
</head>
<body>

<?php
    include("UsrnamePasswrd.php"); 
    $stmt = $pdo->prepare("
                SELECT 
                    User.UserName as UserName, 
                    Song.SongName as Title, 
                    KaraokeFile.version as Version, 
                    Contributors.ContName as Artist, 
                    OrderInfo.time as Time 
                FROM 
                    OrderInfo 
                    INNER JOIN User ON OrderInfo.UserID = User.UserID 
                    INNER JOIN KaraokeFile ON OrderInfo.FileID = KaraokeFile.FileID 
                    INNER JOIN Song ON KaraokeFile.SongID = Song.SongID 
                    INNER JOIN SongCont ON Song.SongID = SongCont.SongID
                    INNER JOIN Contributors ON SongCont.ContID = Contributors.ContID
                WHERE 
                    OrderInfo.QID = 0
                ORDER BY 
                    OrderInfo.time ASC;
            ");

        // Execute the query
        $stmt->execute();

    $currently_playing = "";
    $selected_row = $_POST['selected_row'] ?? '';
    if(isset($_POST['Play'])) {
        // Retrieve the selected row from the database
        $stmt2 = $pdo->prepare("
            SELECT * FROM OrderInfo 
            WHERE UserID = (
                SELECT UserID 
                FROM User 
                WHERE UserName = :username
            )
            AND Title = :title
            AND QID = 0;
        ");
        $stmt2->bindParam(':username', $row['UserName']);
        $stmt2->bindParam(':title', $row['Title']);
        $stmt2->execute();
        $row = $stmt2->fetch(PDO::FETCH_ASSOC);
    
        // Set a flag to indicate that the row has been played
        $played = true;
    }
    
    if(isset($_POST['Delete']) && $played) {
        // Remove selected row from database
        $stmt3 = $pdo->prepare("
            DELETE FROM OrderInfo
            WHERE OrderID = :order_id;
        ");
        $stmt3->bindParam(':order_id', $selected_row);
        $stmt3->execute();
    }

    
?>
    <h1><font color="red"><center>Currently playing:<font color="white"> <?php echo $selected_row; ?></font></center></font></h1>
    <h2><font color="red">Regular Queue</font></h2>
<form action="Djpage.php" method="post" id="DJ1" >

    <table class="tablestyle">
            <thead>
                <tr>
                    <th>UserName</th>
                    <th>SongTitle</th>
                    <th>Version</th>
                    <th>Artist</th>
                    <th>Time</th> 
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    if ($selected_row === $row['Title']) {
                        $currently_playing = htmlspecialchars($row['Title']);
                    }
                    ?>
                    <tr>
                        <td>
                            <label>
                                <input type="radio" name="selected_row" value="<?php echo htmlspecialchars($row['Title']) ?>" <?php if ($selected_row === $row['Title']) {echo "checked";} ?>>
                                <?php echo htmlspecialchars($row['UserName']); ?>
                            </label>
                        </td>
                        <td><?php echo htmlspecialchars($row['Title']); ?></td>
                        <td><?php echo htmlspecialchars($row['Version']); ?></td>
                        <td><?php echo htmlspecialchars($row['Artist']); ?></td>
                        <td><?php echo htmlspecialchars($row['Time']); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>            
            <h2><font color="red">Priority Queue</font></h2>
        <table class="tablestyle">
                <thead>
                    <tr>
                        <th>UserName</th>
                        <th>SongTitle</th>
                        <th>Version</th>
                        <th>Artist</th>
                        <th>Time</th>
                        <th>Payment</th> 
                    </tr>
                </thead>
                <tbody>
                    
                        <?php
                            $time_order = "DESC";
                            $payment_order = "DESC";
                            $sort_button_text = "Sort by Payment";

                            if(isset($_POST['sort_button'])) {
                                if($_POST['sort_button'] == "time") {
                                    $time_order = "ASC";
                                    $sort_button_text = "Sort by Time";
                                } else if($_POST['sort_button'] == "payment") {
                                    $payment_order = "ASC";
                                    $sort_button_text = "Sort by Payment";
                                }
                            }

                            $stmt = $pdo->prepare("
                                SELECT 
                                    User.UserName as UserName, 
                                    Song.SongName as Title, 
                                    KaraokeFile.version as Version, 
                                    Contributors.ContName as Artist, 
                                    OrderInfo.time as Time,
                                    OrderInfo.payment as Payment 
                                FROM 
                                    OrderInfo 
                                    INNER JOIN User ON OrderInfo.UserID = User.UserID 
                                    INNER JOIN KaraokeFile ON OrderInfo.FileID = KaraokeFile.FileID 
                                    INNER JOIN Song ON KaraokeFile.SongID = Song.SongID 
                                    INNER JOIN SongCont ON Song.SongID = SongCont.SongID 
                                    INNER JOIN Contributors ON SongCont.ContID = Contributors.ContID 
                                WHERE 
                                    OrderInfo.QID = 1
                                ORDER BY   
                                    OrderInfo.payment $payment_order, 
                                    OrderInfo.time $time_order;
                            ");
                        ?>
                        <h3><font color="white">Switch Sorting Button</font></h3>
                        <form method="POST" action="">
                            <button type="submit" name="sort_button" value="<?php echo ($time_order == 'ASC') ? 'payment' : 'time'; ?>">
                                <?php echo $sort_button_text; ?>
                            </button>
                        </form>
                            <p></p>

                    <?php
                                     // Execute the query
                    $stmt->execute();
                    ?>
                    
                    <?php while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) { ?>
                            <tr>
                                <td>
                                    <label>
                                        <input type="radio" name="selected_row" value="<?php echo htmlspecialchars($row['Title']) ?>">
                                        <?php echo htmlspecialchars($row['UserName']); ?>
                                    </label>
                                </td>
                                <td><?php echo htmlspecialchars($row['Title']); ?></td>
                                <td><?php echo htmlspecialchars($row['Version']); ?></td>
                                <td><?php echo htmlspecialchars($row['Artist']); ?></td>
                                <td><?php echo htmlspecialchars($row['Time']); ?></td>
                                <td><?php echo htmlspecialchars($row['Payment']); ?></td>
                            </tr>
                        <?php } ?>
                </tbody>
            </table>

            
          
            <script>
                const rows = document.querySelectorAll('tbody tr');
                const radioButtons = document.querySelectorAll('tbody input[type="radio"]');

                radioButtons.forEach((radioButton, index) => {
                    radioButton.addEventListener('click', () => {
                    // Deselect all rows
                    rows.forEach(row => {
                        row.classList.remove('selected');
                    });

                    // Select the clicked row
                    rows[index].classList.add('selected');
                    });
                });
            </script>

            <script>
                        function sortTables(orderBy) {
                        // Get the tables and rows
                        var tables = document.getElementsByTagName("table");
                        var rows = [];
                        for (var i = 0; i < tables.length; i++) {
                            if (tables[i].id === "priority_table" || tables[i].id === "regular_table") {
                            rows.push(...tables[i].querySelectorAll("tbody tr"));
                            }
                        }

                        // Sort the rows
                        rows.sort(function(a, b) {
                            var aTime = a.querySelector("[data-type='time']").textContent;
                            var bTime = b.querySelector("[data-type='time']").textContent;
                            var aPayment = a.querySelector("[data-type='payment']").textContent;
                            var bPayment = b.querySelector("[data-type='payment']").textContent;
                            if (orderBy === "time_asc") {
                            if (aTime < bTime) return -1;
                            if (aTime > bTime) return 1;
                            if (aPayment < bPayment) return -1;
                            if (aPayment > bPayment) return 1;
                            return 0;
                            } else if (orderBy === "time_desc") {
                            if (aTime > bTime) return -1;
                            if (aTime < bTime) return 1;
                            if (aPayment < bPayment) return -1;
                            if (aPayment > bPayment) return 1;
                            return 0;
                            } else if (orderBy === "payment_asc") {
                            if (aPayment < bPayment) return -1;
                            if (aPayment > bPayment) return 1;
                            if (aTime < bTime) return -1;
                            if (aTime > bTime) return 1;
                            return 0;
                            } else if (orderBy === "payment_desc") {
                            if (aPayment > bPayment) return -1;
                            if (aPayment < bPayment) return 1;
                            if (aTime < bTime) return -1;
                            if (aTime > bTime) return 1;
                            return 0;
                            }
                        });

                        // Update the table with the sorted rows
                        var priorityTable = document.getElementById("priority_table");
                        var regularTable = document.getElementById("regular_table");
                        priorityTable.querySelector("tbody").innerHTML = "";
                        regularTable.querySelector("tbody").innerHTML = "";
                        for (var i = 0; i < rows.length; i++) {
                            if (i < 3) {
                            priorityTable.querySelector("tbody").appendChild(rows[i]);
                            } else {
                            regularTable.querySelector("tbody").appendChild(rows[i]);
                            }
                        }
                        }
            </script>


            <style>
                                .selected td {
                                    background-color: lightblue;
                                }
                            </style>
            <br>
        <input type="submit" value="Play">
        

                            </table>
</form>



</body>

</html>
