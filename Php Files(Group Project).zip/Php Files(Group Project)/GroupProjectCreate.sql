CREATE TABLE User ( 

  UserID INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 

  UserName VARCHAR(50) NOT NULL, 

  UserPass VARCHAR(50) NOT NULL, 

  UserEmail VARCHAR(50) NOT NULL 

); 

 
 

CREATE TABLE Song ( 

  SongID INT NOT NULL PRIMARY KEY, 

  SongName VARCHAR(50) NOT NULL 

); 

 
 

CREATE TABLE Contributors ( 

  ContID INT NOT NULL PRIMARY KEY, 

  ContName VARCHAR(50) NOT NULL, 

  contribution VARCHAR(50) NOT NULL 

); 

 
 

CREATE TABLE KaraokeFile ( 

  FileID INT NOT NULL PRIMARY KEY, 

  Version VARCHAR(50) NOT NULL, 

  SongID INT NOT NULL, 

  FOREIGN KEY (SongID) REFERENCES Song (SongID) 

); 

 
 

CREATE TABLE Queue ( 

  QID BIT(1) NOT NULL PRIMARY KEY, 

  Type VARCHAR(50) NOT NULL 

); 

 
 

CREATE TABLE Band ( 

  BandID INT NOT NULL PRIMARY KEY, 

  Bandname VARCHAR(50) NOT NULL 

); 

 
 

CREATE TABLE OrderInfo ( 

  payment DECIMAL(10, 2) UNSIGNED NOT NULL DEFAULT 0.00, 

  time TIME NOT NULL DEFAULT CURRENT_TIME(), 

  UserID INT NOT NULL, 

  QID BIT(1) NOT NULL, 

  FileID INT NOT NULL, 

  PRIMARY KEY (UserID, QID, FileID), 

  FOREIGN KEY (UserID) REFERENCES User (UserID), 

  FOREIGN KEY (QID) REFERENCES Queue (QID), 

  FOREIGN KEY (FileID) REFERENCES KaraokeFile (FileID) 

); 

 
 

CREATE TABLE SongCont ( 

  ContID INT NOT NULL, 

  SongID INT NOT NULL, 

  PRIMARY KEY (ContID, SongID), 

  FOREIGN KEY (ContID) REFERENCES Contributors (ContID), 

  FOREIGN KEY (SongID) REFERENCES Song (SongID) 

); 

 
 

CREATE TABLE BandCont ( 

  BandID INT NOT NULL, 

  ContID INT NOT NULL, 

  PRIMARY KEY (BandID, ContID), 

  FOREIGN KEY (ContID) REFERENCES Contributors (ContID), 

  FOREIGN KEY (BandID) REFERENCES Band (BandID) 

); 

 
 

CREATE TABLE BandSong ( 

  BandID INT NOT NULL, 

  SongID INT NOT NULL, 

  PRIMARY KEY (BandID, SongID), 

  FOREIGN KEY (BandID) REFERENCES Band (BandID), 

  FOREIGN KEY (SongID) REFERENCES Song (SongID) 

); 

 