INSERT INTO User (UserID, UserName, UserPass, UserEmail) VALUES 

  (1, 'ZackAttack', 'zack234', 'zackeat@gmail.com'), 

  (2, 'LoverBoy', 'lovers9342', 'loverslove@yahoo.com'), 

  (3, 'FoodCraver', 'foodieseat432', 'foodieslovetoeat@hotmail.com'), 

  (4, 'ConspiracyBeliever', 'believeme123', 'believer999@acswireless.com'), 

  (5, 'CodGamer', 'lodoverfortnite5554', 'codgamershooter@hotmail.com'), 

  (6, 'CodingGeek', 'c++overanything4233', 'geekforcoding@airtelap.com'), 

  (7, 'TravelGuru', 'goovertheworld3123', 'eyesovertheworld@yahoo.com'), 

  (8, 'IlovePolitics', 'americaisgood321', 'lovepolitics@bplmobile.com'), 

  (9, 'UKculturemongel', 'mongeluk3123', 'ukmongel312@gmail.com'), 

  (10, 'SaveAnimals', 'vetforpets1323', 'animalandvets@hotmail.com') 

; 

 
 

INSERT INTO Song (SongID, SongName) VALUES 

  (1, 'Bad guy'), 

  (2, 'All the Good Girls Go to Hell'), 

  (3, 'Bury a Friend'), 

  (4, 'ME!'), 

  (5, 'You Need to Calm Down'), 

  (6, 'Sunflower'), 

  (7, 'Goodbyes'), 

  (8, 'Senorita'), 

  (9, 'If I Can’t Have You'), 

  (10, 'Stressed Out'), 

  (11, 'Heathens'), 

  (12, 'Billie Jean'), 

  (13, 'My Way'), 

  (14, 'This is What You Came For'), 

  (15, '7 rings'), 

  (16, 'Work'), 

  (17, 'Needed Me'), 

  (18, 'Side to Side'), 

  (19, 'Clocks'), 

  (20, 'Viva la Vida'), 

  (21, 'I Will Wait'), 

  (22, 'Little Lion Man'), 

  (23, 'Mr.Brightside'), 

  (24, 'Radioactive'), 

  (25, 'Somebody That I Used to Know'), 

  (26, 'Can’t Stop'), 

  (27, 'Seven Nation Army'), 

  (28, 'The Middle'), 

  (29, 'Thriller'), 

  (30, 'Circles'), 

 

 

  (31, 'Bad guy'), 

  (32, 'All the Good Girls Go to Hell'), 

  (33, 'Bury a Friend'), 

  (34, 'ME!'), 

  (35, 'You Need to Calm Down'), 

  (36, 'Sunflower'), 

  (37, 'Goodbyes'), 

  (38, 'Senorita'), 

  (39, 'If I Can’t Have You'), 

  (40, 'Stressed Out'), 

  (41, 'Heathens'), 

  (42, 'Billie Jean'), 

  (43, 'My Way'), 

  (44, 'This is What You Came For'), 

  (45, '7 rings'), 

  (46, 'Work'), 

  (47, 'Needed Me'), 

  (48, 'Side to Side'), 

  (49, 'Clocks'), 

  (50, 'Viva la Vida'), 

  (51, 'I Will Wait'), 

  (52, 'Little Lion Man'), 

  (53, 'Mr.Brightside'), 

  (54, 'Radioactive'), 

  (55, 'Somebody That I Used to Know'), 

  (56, 'Can’t Stop'), 

  (57, 'Seven Nation Army'), 

  (58, 'The Middle'), 

  (59, 'Thriller'), 

  (60, 'Circles') 

; 

 
 
 
 

INSERT INTO Contributors (ContID, ContName, contribution) VALUES 

  (1, 'Billie Eilish', 'Vocals'), 

  (2, 'Ariana Grande', 'Vocals'), 

  (3, 'Rihanna', 'Vocals'), 

  (4, 'Taylor Swift', 'Vocals'), 

  (5, 'Michael Jackson', 'Vocals'), 

  (6, 'Jonny Buckland', 'guitar'), 

  (7, 'Guy Berryman', 'bass'), 

  (8, 'Post Malone', 'Vocals'), 

  (9, 'John Frusciante' , 'guitar'), 

  (10, 'Ronnie Vannucci Jr', 'drums'), 

  (11, 'Shawn Mendes', 'guitar'), 

  (12, 'Tyler Joseph', 'piano'), 

  (13, 'Calvin Harris', 'production'), 

  (14, 'Ben Lovett', 'keyboards'), 

  (15, 'Ben McKee', 'bass'), 

  (16, 'Gotye', 'guitar'), 

  (17, 'Meg White', 'drums'), 

  (18, 'Tom Linton', 'Vocals') 

 ; 

 
 

INSERT INTO KaraokeFile (FileID, Version, SongID) VALUES   

(1, 'Solo', 1),   

(2, 'Solo', 2),   

(3, 'Solo', 3),   

(4, 'Solo', 4),   

(5, 'Solo', 5),   

(6, 'Solo', 6),   

(7, 'Solo', 7),   

(8, 'Solo', 8),   

(9, 'Solo', 9),   

(10, 'Solo', 10),   

(11, 'Solo', 11),   

(12, 'Solo', 12),   

(13, 'Solo', 13),   

(14, 'Solo', 14),   

(15, 'Solo', 15),   

(16, 'Solo', 16),   

(17, 'Solo', 17),   

(18, 'Solo', 18),   

(19, 'Solo', 19),   

(20, 'Solo', 20),   

(21, 'Solo', 21),   

(22, 'Solo', 22),   

(23, 'Solo', 23),   

(24, 'Solo', 24),   

(25, 'Solo', 25),   

(26, 'Solo', 26),   

(27, 'Solo', 27),   

(28, 'Solo', 28),   

(29, 'Solo', 29),   

(30, 'Solo', 30), 

(31, 'Duet', 31), 

(32, 'Duet', 32), 

(33, 'Duet', 33), 

(34, 'Duet', 34), 

(35, 'Duet', 35), 

(36, 'Duet', 36), 

(37, 'Duet', 37), 

(38, 'Duet', 38), 

(39, 'Duet', 39), 

(40, 'Duet', 40), 

(41, 'Duet', 41), 

(42, 'Duet', 42), 

(43, 'Duet', 43), 

(44, 'Duet', 44), 

(45, 'Duet', 45), 

(46, 'Duet', 46), 

(47, 'Duet', 47), 

(48, 'Duet', 48), 

(49, 'Duet', 49), 

(50, 'Duet', 50), 

(51, 'Duet', 51), 

(52, 'Duet', 52), 

(53, 'Duet', 53), 

(54, 'Duet', 54), 

(55, 'Duet', 55), 

(56, 'Duet', 56), 

(57, 'Duet', 57), 

(58, 'Duet', 58), 

(59, 'Duet', 59), 

(60, 'Duet', 60) 

; 

 
 

INSERT INTO Queue (QID, Type) VALUES 

(0, 'Regular'), 

(1, 'Accelerated'); 

 
 

INSERT INTO Band (BandID, Bandname) VALUES 

  (1, 'Coldplay'), 

  (2, 'The Killers'), 

  (3, 'Jimmy Eat World'), 

  (4, 'Red Hot Chili Peppers'), 

  (5, 'Mumford & Sons'), 

  (6, 'The White Stripes'), 

  (7, 'Imagine Dragons') 

; 

 
 

INSERT INTO OrderInfo (payment, time, UserID, QID, FileID) VALUES  

  (0.00, 073430, 1, 0, 1), 

  (0.00, 054010, 2, 0, 2), 

  (0.00, 102020, 3, 0, 3), 

  (0.00, 020202, 4, 0, 4), 

  (0.00, 030303, 5, 0, 5), 

  (7.60, 023422, 6, 1, 31), 

  (9.99, 010110, 7, 1, 32), 

  (10.56, 034010, 8, 1, 33), 

  (13.11, 061111, 9, 1, 34), 

  (17.85, 043308, 10, 1, 35) 

; 

 
 
 

 

INSERT INTO SongCont (ContID, SongID) VALUES  

(1, 1), 

(1, 2), 

(1, 3), 

(1, 31), 

(1, 32), 

(1, 33), 

(2, 15), 

(2, 18), 

(2, 45), 

(2, 48), 

(3, 14), 

(3, 16), 

(3, 17), 

(3, 44), 

(3, 46), 

(3, 47), 

(4, 4), 

(4, 5), 

(4, 34), 

(4, 35), 

(5, 12), 

(5, 29), 

(5, 42), 

(5, 59), 

(6, 19), 

(6, 20), 

(6, 49), 

(6, 50), 

(7, 19), 

(7, 20), 

(7, 49), 

(7, 50), 

(8, 6), 

(8, 7), 

(8, 30), 

(8, 36), 

(8, 37), 

(8, 60), 

(9, 26), 

(9, 56), 

(10, 23), 

(10, 53), 

(11, 8), 

(11, 9), 

(11, 38), 

(11, 39), 

(12, 10), 

(12, 11), 

(12, 40), 

(12, 41), 

(13, 13), 

(13, 14), 

(13, 43), 

(13, 44), 

(14, 21), 

(14, 22), 

(14, 51), 

(14, 52), 

(15, 24), 

(15, 54), 

(16, 25), 

(16, 55), 

(17, 27), 

(17, 57), 

(18, 28), 

(18, 58) 

; 
 
 
 

INSERT INTO BandCont(BandID, ContID) VALUES 

(1, 6), 

(1, 7), 

(2, 10), 

(3, 18), 

(4, 9), 

(5, 14), 

(6, 17), 

(7, 15) 

; 

 
 
 

 

 
 

INSERT INTO BandSong(BandID, SongID) VALUES 

(1, 19), 

(1, 20), 

(1, 49), 

(1, 50), 

(2, 23), 

(2, 53), 

(3, 28), 

(3, 58), 

(4, 26), 

(4, 56), 

(5, 21), 

(5, 22), 

(5, 51), 

(5, 52), 

(6, 27), 

(6, 57), 

(7, 24), 

(7, 54) 

;  

 
 
 
 
 
 

 